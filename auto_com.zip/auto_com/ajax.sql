-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 24, 2023 at 01:49 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajax`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`) VALUES
(2, 'Web Development'),
(3, 'Graphic Design'),
(4, 'Digital Marketing'),
(5, 'Web Design sdfdsfsdf');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `name`, `description`) VALUES
(1, 'Thakur Sahiba', 'quick revision best video I have ever seen. really impressed. you cleared my whole basic concepts in a video.'),
(10, 'Manish Prajapati', 'Best 👍👍👍 video, very helpful questions for freshers to prepare css interview, I recommend this video to all fresher designers, thanks 🙏🙏🙏 sir this video helps me a lot'),
(11, 'Vivek Yadav', 'Nice sir ji , add more videos of interview sir'),
(12, 'Jinal Prajapati', 'Verry use full video thank you sir 🙏'),
(13, 'Ravinder Panchal', 'Yeah 😊😊😊 nice video, your content is good and your explanation is very detailed, it helps me a lot, thanks 🙏🙏🙏🙏 keep it up'),
(16, 'Rakesh kumar', 'testing serialize method'),
(17, 'Ajay Yadav', 'Nice AJAX Tutorial'),
(18, 'Bijender Rana', 'Explanation is good');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `doc` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `gender`, `price`, `doc`) VALUES
(2, 'Rahul Goyal', 'rahul@gmail.com', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `cname` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `catid`, `cname`) VALUES
(1, 1, 'HTML & CSS'),
(2, 1, 'Bootstrap'),
(3, 1, 'JavaScript'),
(4, 1, 'jQuery'),
(5, 2, 'PHP & MYSQL'),
(6, 2, 'CodeIgniter'),
(7, 2, 'Laravel'),
(8, 2, 'CakePHP'),
(9, 3, 'Photoshop'),
(10, 3, 'Illustrator'),
(11, 3, 'Corel Draw'),
(12, 4, 'SEO'),
(13, 4, 'SMO'),
(14, 4, 'Google Adwords');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `catid` int(11) DEFAULT NULL,
  `brandid` int(11) DEFAULT NULL,
  `name` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` bigint(20) DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `catid`, `brandid`, `name`, `image`, `price`, `description`) VALUES
(1, 1, 1, 'Men Solid Polo Neck', '1.webp', 495, NULL),
(2, 1, 1, 'Men Solid Round Neck Maroon', '2.webp', 299, NULL),
(3, 1, 2, 'Men Solid Polo Neck Green T-Shirt', '3.webp', 319, NULL),
(4, 1, 2, 'Men Checkered Round Neck Blue T-Shirt', '4.webp', 359, NULL),
(5, 1, 3, 'Men Solid Round Neck Grey Tshirt', '5.webp', 2428, NULL),
(6, 1, 2, 'Pack of 2 Men Striped Round Tshirt', '6.webp', 416, NULL),
(7, 1, 3, 'Men Printed Round Neck Blue T-Shirt', '7.webp', 299, NULL),
(8, 1, 2, 'Pack of 2 Men Printed Round Neck Navy Blue, Grey T-Shirt', '8.webp', 336, NULL),
(9, 1, 2, 'Men Color Block Round Neck Tshirt', '9.webp', 349, NULL),
(10, 1, 2, 'TS1 Men Striped Round Neck Tshirt', '10.webp', 206, NULL),
(11, 1, 3, 'Men Color Block Polo Neck Grey Tshirt', '11.webp', 249, NULL),
(12, 1, 3, 'Men Striped Round Neck Blue T-Shirt', '12.webp', 291, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
